/* common/icucfg.h.  Generated from icucfg.h.in by configure.  */
/* common/icucfg.h.in.  Generated automatically from configure.in by autoheader.  */

/* Define if you have the ANSI C header files.  */
#define STDC_HEADERS 1

/* Define if your processor stores words with the most significant
   byte first (like Motorola and SPARC, unlike Intel and VAX).  */
/* #undef WORDS_BIGENDIAN */

/* Copyright (c) 1999-2000, International Business Machines Corporation and
   others. All Rights Reserved. */
/* Define to signed char if not in <sys/types.h> */
/* #undef int8_t */

/* Define to unsigned char if not in <sys/types.h> */
/* #undef uint8_t */

/* Define to signed short if not in <sys/types.h> */
/* #undef int16_t */

/* Define to unsigned short if not in <sys/types.h> */
/* #undef uint16_t */

/* Define to signed long if not in <sys/types.h> */
/* #undef int32_t */

/* Define to unsigned long if not in <sys/types.h> */
/* #undef uint32_t */

/* Define to signed char if not in <sys/types.h> */
/* #undef bool_t */

/* Define if your system has <wchar.h> */
#define HAVE_WCHAR_H 1

/* Define to the size of wchar_t */
#define SIZEOF_WCHAR_T 4

/* Define if you have the <inttypes.h> header file.  */
#define HAVE_INTTYPES_H 1

/* Define if you have the cma library (-lcma).  */
/* #undef HAVE_LIBCMA */

/* Define if you have the dl library (-ldl).  */
/* #undef HAVE_LIBDL */

/* Define if you have the dld library (-ldld).  */
/* #undef HAVE_LIBDLD */

/* Define if you have the m library (-lm).  */
#define HAVE_LIBM 1

/* Define if you have the pthread library (-lpthread).  */
#define HAVE_LIBPTHREAD 1

/* Define if you have the pthreads library (-lpthreads).  */
/* #undef HAVE_LIBPTHREADS */

/* Define if you have the wcs library (-lwcs).  */
/* #undef HAVE_LIBWCS */
