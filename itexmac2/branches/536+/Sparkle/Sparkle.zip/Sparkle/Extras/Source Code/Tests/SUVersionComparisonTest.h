//
//  SUVersionComparisonTest.h
//  Sparkle
//
//  Created by Andy Matuschak on 4/15/08.
//  Copyright 2008 Andy Matuschak. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>


@interface SUVersionComparisonTest : SenTestCase {

}

@end
